package project;
import java.sql.*;

public class ConnectionProvider {
	public static Connection getCon() {
		try {
			String url="jdbc:mysql://localhost:3306/foodordering?serverTimezone=UTC";
			String username="root";
			String password="Rishi@1997";
			try{
				Class.forName("com.mysql.cj.jdbc.Driver");
			}catch (Exception e) {
				System.out.println(e);  
			}
			Connection con=DriverManager.getConnection(url, username, password);

			return con;
		}catch(Exception e){
			System.out.print(e);
			return null;
		}
	}
}
